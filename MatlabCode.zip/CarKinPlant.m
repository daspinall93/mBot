classdef CarKinPlant < Plant
    %CARKINPLANT Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        
        %% Plant Parameters
        maxVelocity_ms = 1; 
        maxSteerAngle_rad = 0.5;    
        wheelBase_m = 1;
        
    end
    
    methods
        function plant = CarKinPlant()
           
            plant.stepTime_s = 0.1;
            plant.state = [0 0 0]';
            
        end
        
        function init(plant)
            plant.state = [0 0 0]';
        end
        
        function updateState(plant, input)
            
            stateChange = plant.kinematicModel(plant.state(:,end), input) ...
                * plant.stepTime_s;
            plant.state(:,end+1) = plant.state(:,end) + stateChange;        
            
        end
        
        function deriv = kinematicModel(plant, state, input)
           
            deriv = zeros(3,1);
            deriv(1) = input(1) * cos(state(3));
            deriv(2) = input(1) * sin(state(3));
            deriv(3) = (input(1) / plant.wheelBase_m) * tan(input(2));
            
        end
    end
    
end

