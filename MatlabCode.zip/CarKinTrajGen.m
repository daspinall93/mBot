classdef CarKinTrajGen < TrajGen
    %CARKINTRAJGEN Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        distThreshold_m = 0.1;
        randPoseCoVar = diag([4 4 1].^2);
        minDistDiffThreshold_m = 10;
        
    end
    
    methods
        
        function traj = CarKinTrajGen()
            traj.goalPose = [0 0 0]';
        end
        
        function init(traj)
            traj.goalPose = [0 0 0]';
        end
        
        function generateTrajectory(traj, stateEst)
            
            traj.goalPose(:,end+1) = [5 5 0]';
           
            % Determine goal position
            % Check if the distance threshold has been reached, if so
            % generate new goal pose
%             distance = stateEst(1:2) - traj.goalPose(1:2,end);
%             validPoint = false;
%             if distance < traj.distThreshold_m
%                 
%                 while(~validPoint)
%                     newGoalPose = 0 + ...
%                         sqrtm(traj.randPoseCoVar) * randn(3,1);
%                     distance = stateEst(1:2) - newGoalPose(1:2,end);
%                     if distance >= traj.minDistDiffThreshold_m
%                        
%                         validPoint = true;
%                         traj.goalPose(:,end+1) = newGoalPose;
%                         
%                     end
%                     
%                 end
%                 
%             else
%                 traj.goalPose(:,end+1) = traj.goalPose(:,end);
%             end
            
        end
    end
    
end

