classdef CarKinPointCont < Controller
    %CARKINCONT Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        error = [];
        
        maxVelocityDem_ms = 1;
        maxSteerAngleDem_rad = 0.5;
        velocityGain = 0.5;
        steerAngGain = 4;
    end
    
    methods
        
        function cont = CarKinPointCont()
           
            cont.input = []';
            
        end
        
        function init(cont)
            cont.input = []';
        end
        
        function generateInput(cont, stateEst, goalPose)
            % Calculate position error
            cont.error = goalPose(1:2,end) - stateEst(1:2,end);    

            % Velocity Controller
            velocity = cont.velocityGain * sqrt(error(1)^2 + error(2)^2);

            % Heading controller
            thetaSet = atan2(error(2),error(1));
            error(3) = angdiff(thetaSet,stateEst(3,end));
            steerAng = cont.steerAngGain * error(3);
            
            % Limits
            velocity = cont.limitInput(velocity, cont.maxVelocityDem_ms);
            steerAng = cont.limitInput(steerAng, cont.maxSteerAngleDem_rad);
            
            cont.input(:,end+1) = [velocity steerAng]';
        end
        
    end
    
end

