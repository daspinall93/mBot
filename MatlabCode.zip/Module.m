classdef (Abstract = true) Module < handle
    %MODULE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods (Abstract = true)
        
        init();
        
    end
    
end

