classdef (Abstract = true) Observer < Module
    %SENSOR Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Access = public)
        stateEst;
    end
    
    methods (Abstract = true)
        updateStateEst(stateEst, goalPose);
           
    end
    
end

