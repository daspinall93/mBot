classdef (Abstract = true) TrajGen < Module
    %TRAJGEN Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Access = public)
        goalPose;
    end
    
    methods (Abstract = true)
        
        generateTrajectory(stateEst);
        
    end
    
end

