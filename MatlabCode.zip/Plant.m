classdef (Abstract = true) Plant < Module
    %PLANY Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Access = public)
        state;
        stepTime_s;
    end
    
    methods (Abstract = true)
        updateState(input);
            
    end
    
end

