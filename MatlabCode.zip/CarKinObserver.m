classdef CarKinObserver < Observer
    %CARKINOBSERVER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        
        % Sensor parameters
        sensorModelCovarMatrix = [0.2 0; 0 0.01].^2;
        
        % observer parameters
        sensorEstCovarMatrix = diag([0.4 0.02].^2);
        beliefEstCovarMatrix = diag([0.005, 0.005, 0.001].^2);
        
    end
    
    methods
        
        function obs = CarKinObserver()
            
            obs.stateEst = [0 0 0]';
            
        end
        
        function init(obs)
            
            obs.stateEst = [0 0 0]';
            
        end
        
        function updateStateEst(obs, state, input)
           
            % Determine odometry (change in distance and heading)
            stateChange = state(:,end) - state(:,end-1);
            odometry = [norm(stateChange(1:2)) stateChange(3)]';
            
            obs.ekfUpdate(odometry);            

        end
        
        function odometryUpdate(obs, odometry)
            
            % add noise to the odometry to simulate sensor readings
            noisyOdometry = odometry + ...
                (sqrtm(obs.sensorModelCovarMatrix) * randn(2,1));

            % Determine new state estimate from noisy odometry
            stateChangeEst = [noisyOdometry(1) * cos(obs.stateEst(3,end));...
                            noisyOdometry(1) * sin(obs.stateEst(3,end));...
                            noisyOdometry(2)];
            obs.stateEst(:,end+1) = obs.stateEst(:,end) + stateChangeEst; 
            
        end
        
        function ekfUpdate(obs, odometry)
            
            % Predict the new state and its uncertainty
            obs.odometryUpdate(odometry);
            modelRateChangeState = obs.kinModelFx(obs.stateEst(:,end), odometry);
            modelRateChangeUncert = obs.kinModelFv(obs.stateEst(:,end), odometry);
            
            stateUncertUpdate = (modelRateChangeState * obs.beliefEstCovarMatrix(:,:,end)...
                * modelRateChangeState');
            noiseUncertUpdate = (modelRateChangeUncert * ...
                obs.sensorEstCovarMatrix * modelRateChangeUncert');
            obs.beliefEstCovarMatrix(:,:,end+1) = stateUncertUpdate + noiseUncertUpdate;
            
        end
        
        function jacobian = kinModelFx(bike, state, input)
            
            % Calculate rate of change of model w.r.t state vector
            jacobian = [1 0 -(input(1) * sin(state(3)));...
                        0 1 (input(1) * cos(state(3)));...
                        0 0 1];
            
        end
        
        function jacobian = kinModelFv(bike, state, input)
           
            % Calculate rate of change of model w.r.t uncertainty vector
            jacobian = [cos(state(3)) 0;...
                        sin(state(3)) 0;...
                        0 1];
            
        end
        
    end
    
end

