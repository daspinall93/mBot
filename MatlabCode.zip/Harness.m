classdef Harness < handle
    %MODEL Summary of this class goes here
    %   Detailed explanation goes here
    
    properties 
        time_s;
        trajGen;
        controller;
        observer;
        plant;
    end
    
    methods
        
        function h = Harness()
            
            h.trajGen = CarKinTrajGen();
            h.controller = CarKinPointCont();
            h.observer = CarKinObserver();
            h.plant = CarKinPlant();
            
        end
        
        function init(h)
            h.trajGen.init();
            h.controller.init();
            h.observer.init();
            h.plant.init();
        end
        
        function run(h, numberSteps)
            
            h.init();
            
            % Simulation loop
            for step=1:numberSteps
                
                % Check if new goal point is needed
                h.trajGen.generateTrajectory(h.observer.stateEst(:,end));

                % Determine input
                h.controller.generateInput(h.observer.stateEst, h.trajGen.goalPose);
                
                % Step the plant model
                h.plant.updateState(h.controller.input);   
                
                % Determine sensor readings
                h.observer.updateStateEst(h.plant.state, h.controller.input);
                
            end
            
            % Generate time vector
            h.time_s = 0:h.plant.stepTime_s:h.plant.stepTime_s*numberSteps;
        end
        
        function plot(h)
            figure;
            subplot(2,1,1);
            plot(h.time_s, h.plant.state');
            legend('x', 'y', 'theta');
            title('State vs. Time');
            xlabel('t');
            ylabel('x');
            grid minor;
            subplot(2,1,2);
            plot(h.time_s(1:end-1), h.controller.input(1,:));
            hold on;
            grid minor;
            plot(h.time_s(1:end-1), h.controller.input(2,:));
            title('Velocity and steering angle');
            legend('Vel(m/s)', 'Angle(rad)');
            ylabel('t');
            
            % Plot path
            figure;
%             plot(xSet(:,1), xSet(:,2));
%             hold on;
%             line(get(gca,'XLim'), [0 0], 'Color', 'black');
%             line([0 0], get(gca,'YLim'), 'Color', 'black');
            plot(h.plant.state(1,:), h.plant.state(2,:));
            hold on;
            plot(h.observer.stateEst(1,:), h.observer.stateEst(2,:));
            plot(h.trajGen.goalPose(1,2), h.trajGen.goalPose(2,2),...
                'Marker', '.', 'MarkerSize', 10, 'MarkerFaceColor', 'black');
            title('Path vs. Estimated Path');
            xlabel('x');
            ylabel('y');
            zlabel('t');
            legend('Path', 'Estimated Path');
            grid minor;
            
            
        end
        
    end
    
end

