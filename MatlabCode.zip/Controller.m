classdef (Abstract = true) Controller < Module
    %CONTROLLER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Access = public)
        input;
    end
    
    methods (Abstract = true)
        
        generateInput(stateEst, goalPose);
        
    end
    
    methods 
       
        function limitedValue = limitInput(cont, value, limit)
           
            if (value > limit)
                limitedValue = limit;
            elseif (value < -limit)
                limitedValue = -limit;
            else
                limitedValue = value;
            end
            
        end
        
    end
    
end

